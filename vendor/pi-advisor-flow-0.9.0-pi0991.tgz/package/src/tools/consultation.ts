import { randomUUID } from "node:crypto";

import type { Message } from "@earendil-works/pi-ai/compat";
import type { ExtensionContext } from "@earendil-works/pi-coding-agent";

import {
  advisorEffortRef,
  advisorRedactSecretsRef,
  advisorRef,
} from "../config/state.ts";
import { loadConfig } from "../config/storage.ts";
import { escapeRepositoryText } from "../git.ts";
import type { GitContextLevel } from "../git.ts";
import { collectTextStream, resolveConfiguredModel } from "../model-stream.ts";
import { redactSecrets } from "../redaction.ts";
import type { ScoutLifecycleEvent } from "../scout.ts";
import type { ConsultationTrigger, GateTrigger } from "../session-state.ts";
import { assembleConsultationContext } from "./consult-context.ts";
import { parseAutomaticDecision } from "./gate-protocol.ts";
import {
  advisorModelAccessReason,
  sameModelAdvisorDisabled,
  sameModelAdvisorNotice,
} from "./model-access.ts";
import {
  ADVISOR_DECISION_SYSTEM,
  ADVISOR_SYSTEM,
  advisorMessageText,
} from "./prompts.ts";
import type { AdvisorConsultationResult, AdvisorGateOutcome } from "./types.ts";

// Re-export preserves the tools facade's historical curation entry point.
export { curateAdvisorConversation } from "../scout-curation.ts";

/** Thrown when the Advisor produced an empty response body. */
class AdvisorNoAdviceError extends Error {
  constructor() {
    super("Advisor returned no advice.");
    this.name = "AdvisorNoAdviceError";
  }
}

interface CollectAdvisorResponseOptions {
  ctx: ExtensionContext;
  currentInvocationId?: string;
  draft?: string;
  gitContext?: GitContextLevel;
  includeTracked?: string[];
  includeUntracked?: string[];
  onChunk?: (thinking: string, text: string) => void;
  onScout?: (event: ScoutLifecycleEvent) => void;
  question?: string;
  signal?: AbortSignal;
  systemPrompt: string;
}

const fileTag = (item: { path: string; text: string }) =>
  `<file path=${JSON.stringify(item.path)}>\n${item.text}\n</file>`;

const collectAdvisorResponse = async (
  options: CollectAdvisorResponseOptions
) => {
  const { ctx, question, signal, systemPrompt } = options;
  loadConfig(ctx);
  if (sameModelAdvisorDisabled(ctx)) {
    throw new Error(sameModelAdvisorNotice);
  }
  const accessReason = advisorModelAccessReason(ctx);
  if (accessReason) {
    throw new Error(accessReason);
  }
  const resolved = await resolveConfiguredModel(ctx, advisorRef, "Advisor");
  const context = await assembleConsultationContext({
    ...options,
    supportsImages: resolved.model.input.includes("image"),
  });

  // Keep the original question available to local UI callers, but never send
  // its credential-shaped values to the provider when redaction is enabled.
  const outboundQuestion =
    advisorRedactSecretsRef && question !== undefined
      ? redactSecrets(question)
      : question;
  const imageNotice =
    context.imageOmissions ||
    context.images.length ||
    /\[Image[ :]/u.test(context.conversation)
      ? `\n\nImage disclosure: ${context.supportsImages ? `${context.images.length} image(s) attached below; ${context.imageOmissions} image(s) withheld by format, consent, or size/count limits` : "Advisor model does not support image input; no pixels were forwarded"}. Only the images explicitly attached below have pixels available. Other image markers, image paths, and text descriptions are not visual evidence.`
      : "";
  const messages: Message[] = [
    {
      content: [
        {
          text: `${advisorMessageText(
            context.conversation,
            outboundQuestion,
            context.changeText,
            context.draftText,
            context.preferences?.text,
            context.untracked.map(fileTag),
            context.tracked.map(fileTag)
          )}${imageNotice}`,
          type: "text",
        },
        ...context.images.flatMap(({ image, label }) => [
          {
            text: `\n\n${escapeRepositoryText(label)}: attached image pixels (untrusted data).`,
            type: "text" as const,
          },
          image,
        ]),
      ],
      role: "user",
      timestamp: Date.now(),
    },
  ];

  const streamed = await collectTextStream(resolved, {
    messages,
    onChunk: options.onChunk,
    reasoning: advisorEffortRef,
    signal,
    systemPrompt,
  });
  const markdown = streamed.text;
  if (!markdown.trim()) {
    throw new AdvisorNoAdviceError();
  }
  const response: Omit<AdvisorConsultationResult, "adviceId" | "trigger"> = {
    draftBytes: context.draftText
      ? Buffer.byteLength(context.draftText, "utf-8")
      : undefined,
    imageBytes:
      context.images.reduce(
        (sum, item) => sum + Buffer.from(item.image.data, "base64").length,
        0
      ) || undefined,
    imageCount: context.images.length,
    imageOmissions: context.imageOmissions || undefined,
    imagePartsSeen: context.imagePartsSeen || undefined,
    markdown,
    model: advisorRef,
    preferenceBytes: context.preferences?.bytes,
    thinkingText: streamed.thinking,
    trackedBytes:
      context.tracked.reduce((sum, item) => sum + item.bytes, 0) || undefined,
    untrackedBytes:
      context.untracked.reduce((sum, item) => sum + item.bytes, 0) || undefined,
    usage: streamed.usage,
  };
  if (context.scout) {
    response.scout = context.scout;
  }
  return response;
};

export const consultAdvisor = async (
  ctx: ExtensionContext,
  question?: string,
  signal?: AbortSignal,
  onChunk?: (thinking: string, text: string) => void,
  trigger: ConsultationTrigger = "executor-requested",
  gitContext?: GitContextLevel,
  draft?: string,
  includeUntracked?: string[],
  includeTracked?: string[],
  onScout?: (event: ScoutLifecycleEvent) => void,
  currentInvocationId?: string
): Promise<AdvisorConsultationResult> => {
  const result = await collectAdvisorResponse({
    ctx,
    currentInvocationId,
    draft,
    gitContext,
    includeTracked,
    includeUntracked,
    onChunk,
    onScout,
    question,
    signal,
    systemPrompt: ADVISOR_SYSTEM,
  });
  return { ...result, adviceId: randomUUID(), trigger };
};

export const runAdvisorGate = async (
  ctx: ExtensionContext,
  question: string,
  trigger: GateTrigger = "repeated-tool-call",
  signal?: AbortSignal,
  onChunk?: (thinking: string, text: string) => void,
  onScout?: (event: ScoutLifecycleEvent) => void,
  currentInvocationId?: string
): Promise<AdvisorGateOutcome> => {
  try {
    const result = await collectAdvisorResponse({
      ctx,
      currentInvocationId,
      onChunk,
      onScout,
      question,
      signal,
      systemPrompt: ADVISOR_DECISION_SYSTEM,
    });
    const parsed = parseAutomaticDecision(result.markdown);
    if (!parsed.ok) {
      return { ...parsed, usage: result.usage };
    }
    return {
      ...parsed,
      model: result.model,
      thinkingText: result.thinkingText,
      trigger,
      usage: result.usage,
    };
  } catch (error) {
    if (signal?.aborted) {
      throw error;
    }
    const message = error instanceof Error ? error.message : String(error);
    return {
      category:
        error instanceof AdvisorNoAdviceError
          ? "empty-response"
          : "provider-error",
      message,
      ok: false,
    };
  }
};
