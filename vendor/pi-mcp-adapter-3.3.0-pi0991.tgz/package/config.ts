// config.ts - Config loading with import support
import { chmodSync, existsSync, lstatSync, readFileSync, realpathSync, rmSync, statSync, writeFileSync, mkdirSync, renameSync } from "node:fs";
import { homedir } from "node:os";
import { dirname, isAbsolute, join, relative, resolve, sep } from "node:path";
import { parse as parseToml } from "smol-toml";
import stripJsonComments from "strip-json-comments";
import { getAgentPath, getConfigDirName } from "./agent-dir.ts";
import { getAgentPluginSummaries, loadAgentPluginConfigs, type AgentPluginSummary } from "./agent-plugin-loader.ts";
import { cloneBuiltInAgentPluginEntry, isBuiltInAgentPlugin, mergeBuiltInAgentPluginEntries } from "./agent-plugin-provenance.ts";
import { loadClaudePluginBundles } from "./claude-plugin-loader.ts";
import { loadPackageMcpConfigs } from "./package-mcp-loader.ts";
import { validateJevSettings } from "./jev-client.ts";
import { formatServerNamespace, isServerDisabled, type ClaudePluginConfig, type HostConfigDiscovery, type McpConfig, type ServerEntry, type McpSettings, type ImportKind, type ServerProvenance } from "./types.ts";
import { parseJsonWithComments, stripUtf8Bom, toStringRecord } from "./utils.ts";

const GENERIC_GLOBAL_CONFIG_PATH = join(homedir(), ".config", "mcp", "mcp.json");
const AGENTS_GLOBAL_CONFIG_PATHS = [
  join(homedir(), ".agents", "mcp.json"),
  join(homedir(), ".agents", "mcp", "mcp.json"),
] as const;
const PROJECT_CONFIG_NAME = ".mcp.json";
const PI_MCP_CONFIG_NAME = "mcp.json";
const ADAPTER_CONFIG_NAME = "mcp-adapter.json";
const REPOPROMPT_BINARY_CANDIDATES = [
  join(homedir(), "RepoPrompt", "repoprompt_cli"),
  "/Applications/Repo Prompt.app/Contents/MacOS/repoprompt-mcp",
];

export interface KnownServerPreset {
  id: string;
  name: string;
  summary: string;
  entry: ServerEntry;
}

export const KNOWN_SERVER_PRESETS: readonly KnownServerPreset[] = [
  {
    id: "deepwiki",
    name: "DeepWiki",
    summary: "Ask questions about public GitHub repositories.",
    entry: { url: "https://mcp.deepwiki.com/mcp", protocolVersion: "auto" },
  },
  {
    id: "context7",
    name: "Context7",
    summary: "Look up current library documentation and examples.",
    entry: { url: "https://mcp.context7.com/mcp", protocolVersion: "auto" },
  },
  {
    id: "parallel-search",
    name: "Parallel Search",
    summary: "Search the web and fetch pages without an API key.",
    entry: {
      url: "https://search.parallel.ai/mcp",
      protocolVersion: "auto",
      directTools: true,
    },
  },
  {
    id: "notion",
    name: "Notion",
    summary: "Search and work with your Notion workspace.",
    entry: { url: "https://mcp.notion.com/mcp", auth: "oauth", protocolVersion: "auto" },
  },
  {
    id: "github",
    name: "GitHub",
    summary: "Work with GitHub through your Copilot account.",
    entry: { url: "https://api.githubcopilot.com/mcp", auth: "oauth", protocolVersion: "auto" },
  },
  {
    id: "chrome-devtools",
    name: "Chrome DevTools",
    summary: "Inspect and automate a local Chrome browser.",
    entry: { command: "npx", args: ["-y", "chrome-devtools-mcp@1.6.0"] },
  },
];

const IMPORT_PATHS: Record<ImportKind, string[]> = {
  cursor: [join(homedir(), ".cursor", "mcp.json")],
  "claude-code": [
    join(homedir(), ".claude", "mcp.json"),
    join(homedir(), ".claude.json"),
    join(homedir(), ".claude", "claude_desktop_config.json"),
  ],
  "claude-desktop": [join(homedir(), "Library", "Application Support", "Claude", "claude_desktop_config.json")],
  codex: [
    join(homedir(), ".codex", "config.toml"),
    join(homedir(), ".codex", "config.json"),
  ],
  opencode: [
    join(homedir(), ".config", "opencode", "opencode.json"),
    "./opencode.json",
  ],
  windsurf: [join(homedir(), ".windsurf", "mcp.json")],
  vscode: [".vscode/mcp.json"],
};

interface ConfigSourceSpec {
  id: "shared-global" | "agents-global" | "agents-nested-global" | "pi-global" | "shared-project-ancestor" | "pi-project-ancestor" | "shared-project" | "pi-project";
  label: string;
  readPath: string;
  writePath: string;
  kind: "user" | "project" | "import";
  importKind?: string;
  shared: boolean;
  scope: "global" | "project";
}

export interface ConfigDiscoveryPath {
  label: string;
  path: string;
  exists: boolean;
}

export interface DiscoveredImportConfig {
  kind: ImportKind;
  path: string;
}

export interface ConfigDiscoverySource extends ConfigDiscoveryPath {
  id: ConfigSourceSpec["id"];
  scope: ConfigSourceSpec["scope"];
  kind: "shared" | "pi";
  serverCount: number;
}

export interface ImportConfigSummary extends DiscoveredImportConfig {
  serverCount: number;
}

export interface HostConfigSummary extends ImportConfigSummary {
  active: boolean;
}

export interface McpConfigConflict {
  serverName: string;
  sources: Array<{ kind: "shared" | "pi" | "host"; path: string }>;
  winner: { kind: "shared" | "pi" | "host"; path: string };
}

export interface RepoPromptDiscovery {
  configured: boolean;
  configuredPath?: string;
  executablePath?: string;
  targetPath?: string;
  serverName?: string;
  entry?: ServerEntry;
}

export interface McpDiscoverySummary {
  sources: ConfigDiscoverySource[];
  imports: ImportConfigSummary[];
  hostConfigs: HostConfigSummary[];
  hostConfigDiscovery: HostConfigDiscovery;
  agentPlugins: AgentPluginSummary[];
  conflicts: McpConfigConflict[];
  hasAnyConfig: boolean;
  hasAnyDetectedPaths: boolean;
  hasSharedServers: boolean;
  hasPiOwnedServers: boolean;
  totalServerCount: number;
  fingerprint: string;
  repoPrompt: RepoPromptDiscovery;
}

export interface McpStandardConfigSummary {
  sources: ConfigDiscoverySource[];
  hasSharedServers: boolean;
  fingerprint: string;
}

export interface ConfigWritePreview {
  path: string;
  existed: boolean;
  changed: boolean;
  beforeText: string;
  afterText: string;
  diffText: string;
}

export type SharedConfigTarget = "project" | "global";

export function getPiGlobalConfigPath(overridePath?: string): string {
  return overridePath ? resolve(overridePath) : getAgentPath(ADAPTER_CONFIG_NAME);
}

export function getLegacyPiMcpGlobalConfigPath(): string {
  return getAgentPath(PI_MCP_CONFIG_NAME);
}

export function getGenericGlobalConfigPath(): string {
  return GENERIC_GLOBAL_CONFIG_PATH;
}

export function getProjectConfigPath(cwd = process.cwd()): string {
  return resolve(cwd, PROJECT_CONFIG_NAME);
}

export function getProjectPiConfigPath(cwd = process.cwd()): string {
  return resolve(cwd, getConfigDirName(), ADAPTER_CONFIG_NAME);
}

export function getLegacyProjectPiMcpConfigPath(cwd = process.cwd()): string {
  return resolve(cwd, getConfigDirName(), PI_MCP_CONFIG_NAME);
}

/**
 * Adapter-only content in a legacy Pi `mcp.json`. Once Pi's built-in MCP owns the file, its
 * `mcpServers` belong to Pi; `settings`, `imports`, `claudePlugins`, and the legacy
 * `mcp-servers` key are read by neither, so they still need moving.
 */
function legacyMcpConfigHasContent(filePath: string, piOwnsServers: boolean): boolean {
  if (!existsSync(filePath)) return false;
  try {
    const raw = parseJsonWithComments(readFileSync(filePath, "utf-8"));
    if (!isRecord(raw)) return false;
    const hasServers = (value: unknown) => isRecord(value) && Object.keys(value).length > 0;
    return (!piOwnsServers && hasServers(raw.mcpServers))
      || hasServers(raw["mcp-servers"])
      || raw.settings !== undefined
      || raw.imports !== undefined
      || raw.claudePlugins !== undefined;
  } catch {
    return false;
  }
}

export function getLegacyMcpMigrationNotices(cwd = process.cwd(), overridePath?: string, piOwnsServers = false): string[] {
  const explicitPath = overridePath ? resolve(overridePath) : undefined;
  const candidates = [
    [getLegacyPiMcpGlobalConfigPath(), getPiGlobalConfigPath()],
    [getLegacyProjectPiMcpConfigPath(cwd), getProjectPiConfigPath(cwd)],
  ] as const;
  return candidates.flatMap(([source, target]) => {
    // An explicitly selected config is loaded verbatim, whatever its name.
    if (resolve(source) === explicitPath || !legacyMcpConfigHasContent(source, piOwnsServers)) return [];
    if (piOwnsServers) {
      return [`${source} contains pi-mcp-adapter settings that neither Pi nor the adapter reads. Move settings, imports, and claudePlugins into ${target}, and put any "mcp-servers" entries under its "mcpServers" key.`];
    }
    const fix = existsSync(target)
      ? `Merge ${source} into ${target}, then remove ${source}.`
      : `Move it with: mv ${JSON.stringify(source)} ${JSON.stringify(target)}`;
    return [`pi-mcp-adapter no longer reads ${source}. ${fix}`];
  });
}

export function getSharedConfigPath(target: SharedConfigTarget, cwd = process.cwd()): string {
  return target === "project" ? getProjectConfigPath(cwd) : getGenericGlobalConfigPath();
}

export function getConfigDiscoveryPaths(overridePath?: string, cwd = process.cwd()): ConfigDiscoveryPath[] {
  return getConfigSources(overridePath, cwd).map((source) => ({
    label: source.label,
    path: source.readPath,
    exists: existsSync(source.readPath),
  }));
}

export function findAvailableImportConfigs(cwd = process.cwd()): DiscoveredImportConfig[] {
  if (isExclusiveConfigMode()) return [];
  const discovered: DiscoveredImportConfig[] = [];

  for (const importKind of Object.keys(IMPORT_PATHS) as ImportKind[]) {
    const importPath = resolveImportPath(importKind, cwd);
    if (importPath) {
      discovered.push({ kind: importKind, path: importPath });
    }
  }

  return discovered;
}

function getConfigSourceSummaries(sourceSpecs: ConfigSourceSpec[]): ConfigDiscoverySource[] {
  return sourceSpecs.map((source) => {
    const loaded = readValidatedConfig(source.readPath, `MCP config from ${source.readPath}`);
    return {
      id: source.id,
      label: source.label,
      path: source.readPath,
      exists: existsSync(source.readPath),
      scope: source.scope,
      kind: source.shared ? "shared" : "pi",
      serverCount: loaded ? Object.keys(loaded.mcpServers).length : 0,
    } satisfies ConfigDiscoverySource;
  });
}

export function getMcpStandardConfigSummary(overridePath?: string, cwd = process.cwd()): McpStandardConfigSummary {
  const sources = getConfigSourceSummaries(getConfigSources(overridePath, cwd));
  return {
    sources,
    hasSharedServers: sources.some((source) => source.kind === "shared" && source.serverCount > 0),
    fingerprint: JSON.stringify({ sources: sources.map((source) => [source.id, source.exists, source.serverCount]) }),
  };
}

export function getMcpDiscoverySummary(
  overridePath?: string,
  cwd = process.cwd(),
  options: { includeHostConfigs?: boolean } = {},
): McpDiscoverySummary {
  const sourceSpecs = getConfigSources(overridePath, cwd);
  const sources = getConfigSourceSummaries(sourceSpecs);
  const includeHostConfigs = options.includeHostConfigs !== false;

  const importKinds = isExclusiveConfigMode()
    ? (readValidatedConfig(getPiGlobalConfigPath(overridePath), "MCP exclusive config")?.imports ?? [])
    : (Object.keys(IMPORT_PATHS) as ImportKind[]);
  const imports = includeHostConfigs
    ? importKinds
      .map((kind) => {
        const imported = loadImportedConfig(kind, cwd, `Failed to inspect imported MCP config from ${kind}:`);
        if (!imported) return null;
        return {
          kind,
          path: imported.path,
          serverCount: Object.keys(extractServers(imported.value, kind)).length,
        } satisfies ImportConfigSummary;
      })
      .filter((value): value is ImportConfigSummary => value !== null)
    : [];
  const hostConfigDiscovery = isExclusiveConfigMode()
    ? "off"
    : getConfiguredHostConfigDiscovery(overridePath, cwd);
  const hostConfigs = imports.map((entry) => ({ ...entry, active: hostConfigDiscovery === "on" }));
  const settings = getMergedSettings(overridePath, cwd);
  const agentPlugins = isExclusiveConfigMode()
    ? []
    : getAgentPluginSummaries(settings?.agentPluginPaths, cwd);
  const totalServerCount = sources.reduce((sum, source) => sum + source.serverCount, 0) + agentPlugins.reduce((sum, plugin) => sum + plugin.serverCount, 0);
  const hasSharedServers = sources.some((source) => source.kind === "shared" && source.serverCount > 0) || agentPlugins.some(plugin => plugin.serverCount > 0);
  const hasPiOwnedServers = sources.some((source) => source.kind === "pi" && source.serverCount > 0);
  const hasAnyDetectedPaths = sources.some((source) => source.exists) || imports.length > 0 || agentPlugins.length > 0;
  const hasAnyConfig = totalServerCount > 0 || imports.some((entry) => entry.serverCount > 0) || hasAnyDetectedPaths;

  const summaryWithoutRepoPrompt = {
    sources,
    imports,
    hostConfigs,
    hostConfigDiscovery,
    agentPlugins,
    conflicts: getConfigConflicts(sourceSpecs, imports, cwd),
    hasAnyConfig,
    hasAnyDetectedPaths,
    hasSharedServers,
    hasPiOwnedServers,
    totalServerCount,
  };

  const fingerprint = JSON.stringify({
    sources: sources.map((source) => [source.id, source.exists, source.serverCount]),
    imports: imports.map((entry) => [entry.kind, entry.path, entry.serverCount]),
    agentPlugins: agentPlugins.map((entry) => [entry.path, entry.name, entry.serverCount]),
    hostConfigDiscovery,
    conflicts: summaryWithoutRepoPrompt.conflicts,
  });

  return {
    ...summaryWithoutRepoPrompt,
    fingerprint,
    repoPrompt: detectRepoPrompt(summaryWithoutRepoPrompt, cwd),
  };
}

export function cloneMcpConfig(config: McpConfig): McpConfig {
  const cloned = structuredClone(config);
  for (const [name, source] of Object.entries(config.mcpServers)) {
    const builtInClone = cloneBuiltInAgentPluginEntry(source);
    if (builtInClone) cloned.mcpServers[name] = builtInClone;
  }
  return cloned;
}

export interface ProjectServerSource {
  path: string;
}

export interface LoadedMcpConfig {
  config: McpConfig;
  projectServers: Map<string, ProjectServerSource>;
  projectServerPolicy: "ask" | "allow";
}

interface ImportedServerSource {
  path: string;
  scope: "user" | "project";
}

interface LoadedHostConfig {
  config: McpConfig;
  serverSources: Map<string, ImportedServerSource>;
}

export const MCP_CONFIG_SOURCE_METADATA = Symbol.for("pi-mcp-adapter/config-source-metadata");

export function loadMcpConfig(overridePath?: string, cwd = process.cwd()): McpConfig {
  const loaded = loadMcpConfigWithSources(overridePath, cwd);
  Object.defineProperty(loaded.config, MCP_CONFIG_SOURCE_METADATA, {
    value: { projectServers: loaded.projectServers, projectServerPolicy: loaded.projectServerPolicy },
    enumerable: false,
  });
  return loaded.config;
}

export function loadMcpConfigWithSources(overridePath?: string, cwd = process.cwd()): LoadedMcpConfig {
  const sourceSpecs = getConfigSources(overridePath, cwd);
  const hostConfigDiscovery = getConfiguredHostConfigDiscovery(overridePath, cwd);
  const projectServers = new Map<string, ProjectServerSource>();
  let projectServerPolicy: "ask" | "allow" = "ask";
  let projectAgentPluginSource: ProjectServerSource | undefined;
  let projectClaudePluginSource: ProjectServerSource | undefined;
  // Host files are a lower-precedence fallback. This ordering means an opt-in
  // discovery cannot override a shared or adapter-owned definition, and all normal
  // URL-bound credential stripping remains in mergeServerMaps.
  const discoveredHost = !isExclusiveConfigMode() && hostConfigDiscovery === "on"
    ? loadDiscoveredHostConfigs(cwd)
    : { config: { mcpServers: {} }, serverSources: new Map<string, ImportedServerSource>() };
  let config: McpConfig = discoveredHost.config;

  for (const [name, source] of discoveredHost.serverSources) {
    if (source.scope === "project") projectServers.set(name, { path: source.path });
  }

  for (const source of sourceSpecs) {
    const loaded = readValidatedConfig(source.readPath, `MCP config from ${source.readPath}`);
    if (!loaded) continue;
    const expandedImport = expandImports(loaded, cwd);
    const expanded = expandedImport.config;
    const sourceRef = { path: source.readPath };
    if (Object.hasOwn(expanded.settings ?? {}, "agentPluginPaths")) {
      projectAgentPluginSource = source.scope === "project" ? sourceRef : undefined;
    }
    if (expanded.claudePlugins !== undefined) {
      projectClaudePluginSource = source.scope === "project" ? sourceRef : undefined;
    }
    if (source.scope === "project") {
      // Imports expanded by a project file are project-scoped even when they read home-level files.
      for (const name of Object.keys(expanded.mcpServers)) projectServers.set(name, sourceRef);
      if (expanded.settings?.projectServers !== undefined) {
        console.warn(`Ignoring settings.projectServers in project config ${source.readPath}; set it in the user-global MCP config instead`);
        const { projectServers: _ignored, ...settings } = expanded.settings;
        expanded.settings = settings;
      }
    } else if (expanded.settings?.projectServers === "allow" || expanded.settings?.projectServers === "ask") {
      projectServerPolicy = expanded.settings.projectServers;
    }
    for (const [name, importedSource] of expandedImport.serverSources) {
      if (importedSource.scope === "project") projectServers.set(name, { path: importedSource.path });
    }
    config = mergeConfigs(config, expanded);
  }

  if (isExclusiveConfigMode()) {
    return { config: resolveConfiguredClaudePluginMcp(config, cwd), projectServers, projectServerPolicy };
  }

  const packageConfig = loadPackageMcpConfigs(cwd);
  const pluginConfig = loadAgentPluginConfigs(config.settings?.agentPluginPaths, cwd);
  if (projectAgentPluginSource) {
    for (const name of Object.keys(pluginConfig.mcpServers)) projectServers.set(name, projectAgentPluginSource);
  }
  const packageServers = Object.fromEntries(
    Object.entries(packageConfig.mcpServers).filter(([name]) => !Object.hasOwn(pluginConfig.mcpServers, name)),
  );
  for (const name of Object.keys(packageServers)) {
    const source = packageConfig.serverSources.get(name);
    if (source?.scope === "project") projectServers.set(name, { path: source.settingsPath });
  }
  const higherPrecedenceConfig = mergeConfigs(
    { mcpServers: packageServers },
    mergeConfigs(pluginConfig, config),
  );
  const claudePluginServers = new Set<string>();
  const mergedConfig = mergeClaudePluginMcpDefaults(config.claudePlugins, higherPrecedenceConfig, cwd, claudePluginServers);
  if (projectClaudePluginSource) {
    for (const name of claudePluginServers) projectServers.set(name, projectClaudePluginSource);
  }
  return {
    config: mergedConfig,
    projectServers,
    projectServerPolicy,
  };
}

export function resolveConfiguredClaudePluginMcp(config: McpConfig, cwd = process.cwd()): McpConfig {
  return mergeClaudePluginMcpDefaults(config.claudePlugins, config, cwd);
}

export function discoverConfiguredClaudePluginSkills(config: McpConfig, cwd = process.cwd()): string[] {
  return loadClaudePluginBundles(config.claudePlugins, cwd, validateConfig, { mcp: false, skills: true }).skillPaths;
}

function mergeClaudePluginMcpDefaults(
  plugins: ClaudePluginConfig[] | undefined,
  higherPrecedenceConfig: McpConfig,
  cwd: string,
  loadedServerNames?: Set<string>,
): McpConfig {
  const pluginServers = loadClaudePluginBundles(plugins, cwd, validateConfig, { mcp: true, skills: false }).mcpServers;
  const higherNamesByNamespace = new Map(
    Object.keys(higherPrecedenceConfig.mcpServers).map(name => [formatServerNamespace(name), name]),
  );
  const defaults = Object.fromEntries(Object.entries(pluginServers).filter(([name]) => {
    const higherName = higherNamesByNamespace.get(formatServerNamespace(name));
    if (!higherName || higherName === name) return true;
    console.warn(`Claude plugin MCP server "${name}" is shadowed by higher-precedence server "${higherName}" because both normalize to the same namespace`);
    return false;
  }));
  for (const name of Object.keys(defaults)) loadedServerNames?.add(name);
  return applySettingDefaults(mergeConfigs({ mcpServers: defaults }, higherPrecedenceConfig));
}

function applySettingDefaults(config: McpConfig): McpConfig {
  const exposeResources = config.settings?.exposeResources;
  if (exposeResources === undefined) return config;
  const mcpServers = Object.fromEntries(Object.entries(config.mcpServers)
    .map(([name, entry]) => [name, entry.exposeResources === undefined ? { ...entry, exposeResources } : entry]));
  return { ...config, mcpServers };
}

function getMergedSettings(overridePath?: string, cwd = process.cwd()): McpSettings | undefined {
  let settings: McpSettings | undefined;
  for (const source of getConfigSources(overridePath, cwd)) {
    const loaded = readValidatedConfig(source.readPath, `MCP config from ${source.readPath}`);
    if (loaded?.settings) settings = { ...settings, ...loaded.settings };
  }
  return settings;
}

function getConfiguredHostConfigDiscovery(overridePath?: string, cwd = process.cwd()): HostConfigDiscovery {
  let configured: HostConfigDiscovery = "off";
  const settings = getMergedSettings(overridePath, cwd);
  const value = settings?.hostConfigDiscovery;
  if (value === "off" || value === "prompt" || value === "on") configured = value;
  return configured;
}

function loadDiscoveredHostConfigs(cwd: string): LoadedHostConfig {
  let config: McpConfig = { mcpServers: {} };
  const serverSources = new Map<string, ImportedServerSource>();
  for (const importKind of Object.keys(IMPORT_PATHS) as ImportKind[]) {
    const imported = loadImportedConfig(importKind, cwd, `Failed to discover imported MCP config from ${importKind}:`);
    if (!imported) continue;
    const servers = extractServers(imported.value, importKind);
    config = mergeConfigs(config, {
      mcpServers: servers,
    });
    for (const name of Object.keys(servers)) {
      const source = imported.serverSources.get(name);
      if (source?.scope === "project" || !serverSources.has(name)) serverSources.set(name, source ?? imported.source);
    }
  }
  return { config, serverSources };
}

function getConfigConflicts(
  sourceSpecs: ConfigSourceSpec[],
  imports: ImportConfigSummary[],
  cwd: string,
): McpConfigConflict[] {
  const seen = new Map<string, Array<{ kind: "shared" | "pi" | "host"; path: string }>>();
  const record = (name: string, source: { kind: "shared" | "pi" | "host"; path: string }): void => {
    const entries = seen.get(name) ?? [];
    if (!entries.some((entry) => entry.kind === source.kind && entry.path === source.path)) entries.push(source);
    seen.set(name, entries);
  };

  // Host candidates are listed first because, when enabled, they are the
  // lowest-precedence fallback. The fixed IMPORT_PATHS order is deterministic.
  for (const entry of imports) {
    const imported = loadImportedConfig(entry.kind, cwd, `Failed to inspect imported MCP config from ${entry.kind}:`);
    if (!imported) continue;
    for (const name of Object.keys(extractServers(imported.value, entry.kind))) {
      record(name, { kind: "host", path: imported.path });
    }
  }
  for (const source of sourceSpecs) {
    const loaded = readValidatedConfig(source.readPath, `MCP config from ${source.readPath}`);
    if (!loaded) continue;
    if (loaded.imports?.length) {
      for (const importKind of loaded.imports) {
        const imported = loadImportedConfig(importKind, cwd, `Failed to inspect imported MCP config from ${importKind}:`);
        if (!imported) continue;
        for (const name of Object.keys(extractServers(imported.value, importKind))) {
          record(name, { kind: "host", path: imported.path });
        }
      }
    }
    for (const name of Object.keys(loaded.mcpServers)) {
      record(name, {
        kind: source.shared ? "shared" : "pi",
        path: source.readPath,
      });
    }
  }

  return [...seen.entries()]
    .filter(([, sources]) => sources.length > 1)
    .map(([serverName, sources]) => ({ serverName, sources, winner: sources[sources.length - 1]! }))
    .sort((left, right) => left.serverName.localeCompare(right.serverName));
}

function getConfigSources(overridePath?: string, cwd = process.cwd()): ConfigSourceSpec[] {
  const userPath = getPiGlobalConfigPath(overridePath);
  const projectPath = getProjectConfigPath(cwd);
  const projectPiPath = getProjectPiConfigPath(cwd);
  const sources: ConfigSourceSpec[] = [];

  if (isExclusiveConfigMode()) {
    return [{
      id: "pi-global",
      label: "Pi exclusive config",
      readPath: userPath,
      writePath: userPath,
      kind: "user",
      shared: false,
      scope: "global",
    }];
  }

  if (GENERIC_GLOBAL_CONFIG_PATH !== userPath) {
    sources.push({
      id: "shared-global",
      label: "user-global standard MCP",
      readPath: GENERIC_GLOBAL_CONFIG_PATH,
      writePath: userPath,
      kind: "import",
      importKind: "global MCP config",
      shared: true,
      scope: "global",
    });
  }

  for (const [index, agentsPath] of AGENTS_GLOBAL_CONFIG_PATHS.entries()) {
    if (agentsPath === userPath || agentsPath === GENERIC_GLOBAL_CONFIG_PATH) continue;
    sources.push({
      id: index === 0 ? "agents-global" : "agents-nested-global",
      label: index === 0 ? "user-global .agents MCP" : "user-global .agents nested MCP",
      readPath: agentsPath,
      writePath: userPath,
      kind: "import",
      importKind: index === 0 ? ".agents MCP config" : ".agents/mcp MCP config",
      shared: true,
      scope: "global",
    });
  }

  sources.push({
    id: "pi-global",
    label: "MCP adapter global override",
    readPath: userPath,
    writePath: userPath,
    kind: "user",
    shared: false,
    scope: "global",
  });

  // Compare file identities so symlink aliases cannot reload a global source
  // at ancestor precedence. Keep original paths for display and writes.
  const reservedPaths = new Set([
    ...sources.map((source) => getConfigPathIdentity(source.readPath)),
    getConfigPathIdentity(projectPath),
    getConfigPathIdentity(projectPiPath),
  ]);
  // Only user-global files (including an explicit override) may opt in to
  // ancestor discovery. Project files cannot extend this trust boundary.
  const ancestorSources = new Map<string, ConfigSourceSpec>();
  const descriptors = [
    { id: "shared-project-ancestor", label: "ancestor standard MCP", path: getProjectConfigPath, shared: true },
    { id: "pi-project-ancestor", label: "ancestor MCP adapter override", path: getProjectPiConfigPath, shared: false },
  ] as const;
  const ancestorRoot = getConfiguredAncestorRoot(sources, cwd);
  if (ancestorRoot) {
    for (const dir of getAncestorProjectDirs(cwd, ancestorRoot)) {
      for (const descriptor of descriptors) {
        const path = descriptor.path(dir);
        const identity = getConfigPathIdentity(path);
        if (reservedPaths.has(identity) || !existsSync(path)) continue;
        // Reinsert aliases at their nearest precedence position.
        ancestorSources.delete(identity);
        ancestorSources.set(identity, {
          id: descriptor.id,
          label: descriptor.label,
          readPath: path,
          writePath: path,
          kind: "project",
          shared: descriptor.shared,
          scope: "project",
        });
      }
    }
  }
  sources.push(...ancestorSources.values());

  if (projectPath !== userPath) {
    sources.push({
      id: "shared-project",
      label: "project standard MCP",
      readPath: projectPath,
      writePath: projectPath,
      kind: "project",
      shared: true,
      scope: "project",
    });
  }

  if (projectPiPath !== userPath && projectPiPath !== projectPath) {
    sources.push({
      id: "pi-project",
      label: "project MCP adapter override",
      readPath: projectPiPath,
      writePath: projectPiPath,
      kind: "project",
      shared: false,
      scope: "project",
    });
  }

  return sources;
}

function getConfigPathIdentity(path: string): string {
  try {
    return realpathSync(path);
  } catch {
    // Missing or inaccessible paths still participate in lexical deduplication.
    return resolve(path);
  }
}

function isWithin(base: string, target: string): boolean {
  const path = relative(base, target);
  return path !== ".." && !path.startsWith(`..${sep}`) && !isAbsolute(path);
}

function getConfiguredAncestorRoot(globalSources: ConfigSourceSpec[], cwd: string): string | undefined {
  let configured: unknown;
  for (const source of globalSources) {
    const roots = readValidatedConfig(source.readPath, `MCP config from ${source.readPath}`)?.settings?.ancestorConfigRoots;
    if (roots !== undefined) configured = roots;
  }
  if (configured === undefined || (Array.isArray(configured) && configured.length === 0)) return undefined;
  if (!Array.isArray(configured)) {
    console.warn("Invalid settings.ancestorConfigRoots: expected an array of paths");
    return undefined;
  }

  const home = getConfigPathIdentity(resolve(homedir()));
  const canonicalCwd = getConfigPathIdentity(resolve(cwd));
  const valid: string[] = [];
  for (const entry of configured) {
    const expanded = typeof entry === "string" && entry.startsWith("~/")
      ? join(homedir(), entry.slice(2))
      : entry;
    if (typeof expanded !== "string" || !isAbsolute(expanded)) {
      console.warn(`Invalid settings.ancestorConfigRoots entry ${JSON.stringify(entry)}: expected an absolute path or ~/...`);
      continue;
    }
    try {
      const root = realpathSync(expanded);
      if (!statSync(root).isDirectory() || !isWithin(home, root)) throw new Error();
      if (isWithin(root, canonicalCwd)) valid.push(root);
    } catch {
      console.warn(`Invalid settings.ancestorConfigRoots entry ${JSON.stringify(entry)}: expected an existing directory under HOME`);
    }
  }
  return valid.sort((left, right) => right.length - left.length)[0];
}

function getAncestorProjectDirs(cwd: string, root: string): string[] {
  const start = getConfigPathIdentity(resolve(cwd));
  const dirs: string[] = [];
  let current = dirname(start);
  while (isWithin(root, current)) {
    dirs.unshift(current);
    if (current === root) break;
    const parent = dirname(current);
    if (parent === current) break;
    current = parent;
  }
  return dirs;
}

function isExclusiveConfigMode(): boolean {
  return process.env.PI_MCP_CONFIG_MODE?.trim().toLowerCase() === "exclusive";
}

function mergeConfigs(base: McpConfig, next: McpConfig): McpConfig {
  const imports = mergeImports(base.imports, next.imports);
  const settings = next.settings ? { ...base.settings, ...next.settings } : base.settings;
  const claudePlugins = next.claudePlugins ?? base.claudePlugins;
  return {
    mcpServers: mergeServerMaps(base.mcpServers, next.mcpServers),
    ...(imports !== undefined ? { imports } : {}),
    ...(settings !== undefined ? { settings } : {}),
    ...(claudePlugins !== undefined ? { claudePlugins } : {}),
  };
}

// Credential-bearing fields whose value is bound to a specific server `url`.
// When a higher-precedence config source repoints an existing server at a
// different url, these MUST NOT be inherited from the lower-precedence entry —
// otherwise the original endpoint's credentials would be shipped to the new
// url. See the SECURITY note in mergeServerMaps.
const URL_BOUND_AUTH_FIELDS = ["headers", "bearerToken", "bearerTokenEnv", "bearerTokenStore", "requestHeadersCommand", "caFile"] as const;

function mergeServerMaps(
  base: Record<string, ServerEntry>,
  next: Record<string, ServerEntry>,
): Record<string, ServerEntry> {
  const merged = { ...base };
  for (const [name, definition] of Object.entries(next)) {
    const existing = merged[name];
    // SECURITY (credential/url binding): the merge is per-field, so a
    // higher-precedence source that supplies only a new `url` for an existing
    // server would otherwise retain the lower-precedence entry's auth material
    // (Authorization header, bearer token, OAuth config) and send it to the new
    // url — a credential-exfiltration vector when the higher-precedence source
    // is less trusted than the one that first defined the server. Bind auth to
    // the url that supplied it: when the url changes, drop inherited auth
    // material before merging. Auth explicitly re-supplied by `definition` still
    // applies (it is spread last). Behaviour is unchanged when the url is
    // identical or the override omits `url` (partial overrides still inherit).
    let baseEntry: ServerEntry = existing ?? {};
    if (existing && typeof definition.command === "string") {
      baseEntry = { ...existing };
      for (const field of [
        "url", "headers", "requestHeadersCommand", "caFile", "auth", "bearerToken",
        "bearerTokenEnv", "bearerTokenStore", "oauth", "httpTransport", "socket",
      ] as const) {
        delete baseEntry[field];
      }
    } else if (existing && typeof definition.url === "string") {
      baseEntry = { ...existing };
      for (const field of [
        "command", "args", "env", "cwd", "pluginDataDir", "literalEnv", "inheritEnv", "socket",
      ] as const) {
        delete baseEntry[field];
      }
    } else if (existing && typeof definition.socket === "string") {
      baseEntry = { ...existing };
      for (const field of [
        "command", "args", "env", "cwd", "pluginDataDir", "literalEnv", "inheritEnv", "url",
        "headers", "requestHeadersCommand", "caFile", "auth", "bearerToken", "bearerTokenEnv",
        "bearerTokenStore", "oauth", "httpTransport",
      ] as const) {
        delete baseEntry[field];
      }
    }
    if (existing && typeof definition.url === "string" && definition.url !== existing.url) {
      if (baseEntry === existing) baseEntry = { ...existing };
      for (const field of URL_BOUND_AUTH_FIELDS) {
        delete baseEntry[field];
      }
      if (baseEntry.oauth !== false) {
        delete baseEntry.oauth;
      }
    }
    if (existing && Object.hasOwn(definition, "env") && isBuiltInAgentPlugin(existing, "env") && !Object.hasOwn(definition, "literalEnv")) {
      if (baseEntry === existing) baseEntry = { ...existing };
      delete baseEntry.literalEnv;
    }
    merged[name] = mergeBuiltInAgentPluginEntries(baseEntry, definition);
  }
  return merged;
}

function mergeImports(left: ImportKind[] | undefined, right: ImportKind[] | undefined): ImportKind[] | undefined {
  const merged = [...(left ?? []), ...(right ?? [])];
  if (merged.length === 0) return undefined;
  return [...new Set(merged)];
}

function expandImports(config: McpConfig, cwd = process.cwd()): LoadedHostConfig {
  if (!config.imports?.length) return { config, serverSources: new Map() };

  const importedServers: Record<string, ServerEntry> = {};
  const serverSources = new Map<string, ImportedServerSource>();
  for (const importKind of config.imports) {
    const imported = loadImportedConfig(importKind, cwd, `Failed to import MCP config from ${importKind}:`);
    if (!imported) continue;

    const servers = extractServers(imported.value, importKind);
    for (const [name, definition] of Object.entries(servers)) {
      if (!importedServers[name]) {
        importedServers[name] = definition;
        serverSources.set(name, imported.serverSources.get(name) ?? imported.source);
      }
    }
  }

  return {
    config: {
      imports: config.imports,
      ...(config.settings !== undefined ? { settings: config.settings } : {}),
      ...(config.claudePlugins !== undefined ? { claudePlugins: config.claudePlugins } : {}),
      mcpServers: mergeServerMaps(importedServers, config.mcpServers),
    },
    serverSources,
  };
}

function resolveImportCandidates(importKind: ImportKind, cwd: string): ImportedServerSource[] {
  return (IMPORT_PATHS[importKind] ?? []).map((candidate) => {
    const scope = candidate.startsWith(".") ? "project" : "user";
    if (importKind === "opencode" && candidate === "./opencode.json") {
      const start = resolve(cwd);
      let gitRoot: string | undefined;
      let current = start;
      while (true) {
        if (existsSync(join(current, ".git"))) {
          gitRoot = current;
          break;
        }
        const parent = dirname(current);
        if (parent === current) break;
        current = parent;
      }

      if (!gitRoot) return { path: join(start, "opencode.json"), scope };
      current = start;
      while (true) {
        const projectConfig = join(current, "opencode.json");
        if (existsSync(projectConfig) || current === gitRoot) return { path: projectConfig, scope };
        current = dirname(current);
      }
    }
    return { path: candidate.startsWith(".") ? resolve(cwd, candidate) : candidate, scope };
  });
}

function readImportedConfig(path: string): unknown {
  const raw = readFileSync(path, "utf-8");
  return path.endsWith(".toml") ? parseToml(stripUtf8Bom(raw)) : parseJsonWithComments(raw);
}

function loadImportedConfig(
  importKind: ImportKind,
  cwd: string,
  warningPrefix: string,
): { path: string; value: unknown; source: ImportedServerSource; serverSources: Map<string, ImportedServerSource> } | null {
  if (importKind === "opencode") {
    let merged: Record<string, unknown> = {};
    let highestPrecedenceSource: ImportedServerSource | undefined;
    const serverSources = new Map<string, ImportedServerSource>();

    for (const source of resolveImportCandidates(importKind, cwd)) {
      const { path } = source;
      if (!existsSync(path)) continue;

      try {
        const value = readImportedConfig(path);
        if (value && typeof value === "object" && !Array.isArray(value)) {
          const imported = value as Record<string, unknown>;
          const mcp = isRecord(imported.mcp) ? imported.mcp : {};
          // OpenCode v2 nests definitions under mcp.servers; normalize before
          // merging so project overrides retain the existing merge semantics.
          const entries = isRecord(mcp.servers)
            ? { ...Object.fromEntries(Object.entries(mcp).filter(([name]) => name !== "servers" && name !== "timeout")), ...mcp.servers }
            : mcp;
          const normalized = Object.fromEntries(Object.entries(entries).map(([name, entry]) => {
            if (!isRecord(entry) || !isRecord(entry.oauth)) return [name, entry];
            const { client_id, client_secret, auth_server_metadata_url, ...oauth } = entry.oauth;
            return [name, {
              ...entry,
              oauth: {
                ...oauth,
                ...(client_id !== undefined ? { clientId: client_id } : {}),
                ...(client_secret !== undefined ? { clientSecret: client_secret } : {}),
                ...(auth_server_metadata_url !== undefined ? { authServerMetadataUrl: auth_server_metadata_url } : {}),
              },
            }];
          }));
          merged = mergeOpenCodeConfigs(merged, { ...imported, mcp: normalized });
          for (const name of Object.keys(normalized)) serverSources.set(name, source);
          highestPrecedenceSource = source;
        }
      } catch (error) {
        console.warn(warningPrefix, error);
      }
    }

    if (!highestPrecedenceSource) return null;
    const finalNames = new Set(Object.keys(extractServers(merged, importKind)));
    for (const name of serverSources.keys()) {
      if (!finalNames.has(name)) serverSources.delete(name);
    }
    return {
      path: highestPrecedenceSource.path,
      value: merged,
      source: highestPrecedenceSource,
      serverSources,
    };
  }

  for (const source of resolveImportCandidates(importKind, cwd)) {
    const { path } = source;
    if (!existsSync(path)) continue;

    try {
      const value = readImportedConfig(path);
      return {
        path,
        value,
        source,
        serverSources: new Map(Object.keys(extractServers(value, importKind)).map(name => [name, source])),
      };
    } catch (error) {
      console.warn(warningPrefix, error);
    }
  }

  return null;
}

function resolveImportPath(importKind: ImportKind, cwd = process.cwd()): string | null {
  return loadImportedConfig(importKind, cwd, `Failed to discover imported MCP config from ${importKind}:`)?.path ?? null;
}

function readValidatedConfig(path: string, label: string): McpConfig | null {
  if (!existsSync(path)) return null;

  try {
    const text = readFileSync(path, "utf-8");
    if (stripJsonComments(text, { trailingCommas: true }).trim() === "") return null;
    return validateConfig(parseJsonWithComments(text));
  } catch (error) {
    console.warn(`Failed to load ${label}:`, error);
    return null;
  }
}

function validateConfig(raw: unknown): McpConfig {
  if (!isRecord(raw)) {
    return { mcpServers: {} };
  }

  return {
    mcpServers: toServerEntries(raw.mcpServers ?? raw["mcp-servers"]),
    ...(Array.isArray(raw.imports) ? { imports: raw.imports as ImportKind[] } : {}),
    ...(raw.settings !== undefined ? { settings: parseSettings(raw.settings) } : {}),
    ...(raw.claudePlugins !== undefined ? { claudePlugins: parseClaudePlugins(raw.claudePlugins) } : {}),
  };
}

function parseSettings(value: unknown): McpSettings {
  if (!isRecord(value)) throw new Error("settings must be an object");
  const settings = { ...value } as McpSettings;
  if (value.jev !== undefined) {
    validateJevSettings(value.jev);
    settings.jev = value.jev as NonNullable<McpSettings["jev"]>;
  }
  return settings;
}

function parseClaudePlugins(value: unknown): ClaudePluginConfig[] {
  if (!Array.isArray(value)) {
    console.warn("Invalid claudePlugins config: expected an array");
    return [];
  }

  const plugins: ClaudePluginConfig[] = [];
  for (const [index, entry] of value.entries()) {
    if (!isRecord(entry) || typeof entry.path !== "string" || entry.path.trim().length === 0) {
      console.warn(`Invalid claudePlugins[${index}]: expected an object with a non-empty path`);
      continue;
    }
    if ((entry.mcp !== undefined && typeof entry.mcp !== "boolean") || (entry.skills !== undefined && typeof entry.skills !== "boolean")) {
      console.warn(`Invalid claudePlugins[${index}] for ${entry.path}: mcp and skills must be booleans`);
      continue;
    }
    if (entry.mcp !== true && entry.skills !== true) {
      console.warn(`Invalid claudePlugins[${index}] for ${entry.path}: enable mcp, skills, or both`);
      continue;
    }
    plugins.push({
      path: entry.path,
      ...(entry.mcp !== undefined ? { mcp: entry.mcp } : {}),
      ...(entry.skills !== undefined ? { skills: entry.skills } : {}),
    });
  }
  return plugins;
}

function toServerEntries(servers: unknown): Record<string, ServerEntry> {
  if (!isRecord(servers)) return {};
  const entries: Record<string, ServerEntry> = {};
  for (const [name, entry] of Object.entries(servers)) {
    if (isServerEntry(entry)) entries[name] = entry;
  }
  return entries;
}

function isServerEntry(value: unknown): value is ServerEntry {
  return isRecord(value);
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

function mergeOpenCodeConfigs(base: Record<string, unknown>, next: Record<string, unknown>): Record<string, unknown> {
  const baseMcp = base.mcp;
  const nextMcp = next.mcp;
  const mergedMcp: Record<string, unknown> = {
    ...(baseMcp && typeof baseMcp === "object" && !Array.isArray(baseMcp) ? baseMcp : {}),
  };

  if (nextMcp && typeof nextMcp === "object" && !Array.isArray(nextMcp)) {
    for (const [name, nextEntry] of Object.entries(nextMcp)) {
      const baseEntry = mergedMcp[name];
      if (
        baseEntry && typeof baseEntry === "object" && !Array.isArray(baseEntry)
        && nextEntry && typeof nextEntry === "object" && !Array.isArray(nextEntry)
      ) {
        const safeBase = { ...(baseEntry as Record<string, unknown>) };
        const override = nextEntry as Record<string, unknown>;
        if (typeof override.type === "string" && override.type !== safeBase.type) {
          for (const field of ["command", "environment", "cwd", "url", "headers", "oauth"]) delete safeBase[field];
        }
        if (typeof override.url === "string" && override.url !== safeBase.url) {
          delete safeBase.headers;
          delete safeBase.oauth;
        }
        if (Array.isArray(override.command)) {
          const baseCommand = safeBase.command;
          const commandChanged = !Array.isArray(baseCommand)
            || override.command.length !== baseCommand.length
            || override.command.some((value, index) => value !== baseCommand[index]);
          if (commandChanged) {
            delete safeBase.environment;
            delete safeBase.cwd;
          }
        }

        const mergedEntry = { ...safeBase, ...override };
        for (const field of ["environment", "headers", "oauth"]) {
          const baseField = safeBase[field];
          const nextField = override[field];
          if (
            baseField && typeof baseField === "object" && !Array.isArray(baseField)
            && nextField && typeof nextField === "object" && !Array.isArray(nextField)
          ) {
            mergedEntry[field] = { ...(baseField as Record<string, unknown>), ...(nextField as Record<string, unknown>) };
          }
        }
        mergedMcp[name] = mergedEntry;
      } else {
        mergedMcp[name] = nextEntry;
      }
    }
  }

  return { ...base, ...next, mcp: mergedMcp };
}

function extractServers(config: unknown, kind: ImportKind): Record<string, ServerEntry> {
  if (!config || typeof config !== "object") return {};

  const obj = config as Record<string, unknown>;

  let servers: unknown;
  switch (kind) {
    case "claude-desktop":
    case "claude-code":
      servers = obj.mcpServers;
      break;
    case "codex":
      servers = obj.mcp_servers ?? obj.mcpServers;
      break;
    case "cursor":
    case "windsurf":
    case "vscode":
      servers = obj.mcpServers ?? obj["mcp-servers"];
      break;
    case "opencode":
      servers = obj.mcp;
      break;
    default:
      return {};
  }

  if (!servers || typeof servers !== "object" || Array.isArray(servers)) {
    return {};
  }

  const mappedServers: Record<string, ServerEntry> = {};
  for (const [name, entry] of Object.entries(servers)) {
    if (kind === "opencode") {
      if (!entry || typeof entry !== "object" || Array.isArray(entry)) continue;
      const raw = entry as Record<string, unknown>;
      if (raw.enabled === false || raw.disabled === true) continue;

      if (raw.type === "local" && Array.isArray(raw.command) && raw.command.length > 0 && raw.command.every((value): value is string => typeof value === "string")) {
        const env = toStringRecord(raw.environment);
        const command = raw.command[0];
        if (command === undefined) continue;
        const mapped: ServerEntry = {
          command,
          args: raw.command.slice(1),
          ...(env ? { env } : {}),
          ...(typeof raw.cwd === "string" ? { cwd: raw.cwd } : {}),
        };
        mappedServers[name] = mapped;
        continue;
      }

      if (raw.type === "remote" && typeof raw.url === "string") {
        const headers = toStringRecord(raw.headers);
        const mapped: ServerEntry = {
          url: raw.url,
          ...(headers ? { headers } : {}),
        };
        if (raw.oauth === false) {
          mapped.oauth = false;
        } else if (raw.oauth && typeof raw.oauth === "object" && !Array.isArray(raw.oauth)) {
          const oauth = raw.oauth as Record<string, unknown>;
          mapped.auth = "oauth";
          const clientId = oauth.clientId;
          const clientSecret = oauth.clientSecret;
          const authServerMetadataUrl = oauth.authServerMetadataUrl;
          mapped.oauth = {
            ...(typeof clientId === "string" ? { clientId } : {}),
            ...(typeof clientSecret === "string" ? { clientSecret } : {}),
            ...(typeof oauth.clientMetadataUrl === "string" ? { clientMetadataUrl: oauth.clientMetadataUrl } : {}),
            ...(typeof oauth.scope === "string" ? { scope: oauth.scope } : {}),
            ...(typeof authServerMetadataUrl === "string" ? { authServerMetadataUrl } : {}),
            ...(typeof oauth.skipIssuerMetadataValidation === "boolean"
              ? { skipIssuerMetadataValidation: oauth.skipIssuerMetadataValidation }
              : {}),
          };
        }
        mappedServers[name] = mapped;
      }
      continue;
    }

    if (!isRecord(entry)) continue;
    if (kind !== "codex") {
      mappedServers[name] = entry;
      continue;
    }

    const mapped = { ...entry };
    const bearerTokenEnv = mapped.bearer_token_env_var;
    const httpHeaders = mapped.http_headers;
    const envHttpHeaders = mapped.env_http_headers;

    if (typeof bearerTokenEnv === "string") {
      mapped.bearerTokenEnv = bearerTokenEnv;
      if (mapped.auth === undefined) mapped.auth = "bearer";
    }
    if (httpHeaders && typeof httpHeaders === "object" && !Array.isArray(httpHeaders)) {
      mapped.headers = { ...(mapped.headers as Record<string, string> | undefined), ...(httpHeaders as Record<string, string>) };
    }
    if (envHttpHeaders && typeof envHttpHeaders === "object" && !Array.isArray(envHttpHeaders)) {
      const headers = { ...(mapped.headers as Record<string, string> | undefined) };
      for (const [header, envVar] of Object.entries(envHttpHeaders)) {
        if (typeof envVar === "string" && headers[header] === undefined) headers[header] = `$env:${envVar}`;
      }
      mapped.headers = headers;
    }

    delete mapped.bearer_token_env_var;
    delete mapped.http_headers;
    delete mapped.env_http_headers;
    mappedServers[name] = mapped as ServerEntry;
  }

  return mappedServers;
}

function serializeRawConfig(raw: Record<string, unknown>): string {
  return `${JSON.stringify(raw, null, 2)}\n`;
}

function buildUnifiedDiff(beforeText: string, afterText: string): string {
  if (beforeText === afterText) return "(no changes)";

  const before = beforeText.split("\n");
  const after = afterText.split("\n");
  const rows = before.length;
  const cols = after.length;
  const lcs = Array.from({ length: rows + 1 }, () => Array<number>(cols + 1).fill(0));

  for (let i = rows - 1; i >= 0; i--) {
    for (let j = cols - 1; j >= 0; j--) {
      const row = lcs[i];
      const nextRow = lcs[i + 1];
      if (!row || !nextRow) continue;
      row[j] = before[i] === after[j]
        ? (nextRow[j + 1] ?? 0) + 1
        : Math.max(nextRow[j] ?? 0, row[j + 1] ?? 0);
    }
  }

  const lines: string[] = ["--- before", "+++ after"];
  let i = 0;
  let j = 0;
  while (i < rows || j < cols) {
    if (i < rows && j < cols && before[i] === after[j]) {
      lines.push(`  ${before[i]}`);
      i++;
      j++;
      continue;
    }
    if (j < cols && (i === rows || (lcs[i]?.[j + 1] ?? 0) >= (lcs[i + 1]?.[j] ?? 0))) {
      lines.push(`+ ${after[j]}`);
      j++;
      continue;
    }
    if (i < rows) {
      lines.push(`- ${before[i]}`);
      i++;
    }
  }

  return lines.join("\n");
}

function buildConfigWritePreview(filePath: string, nextRaw: Record<string, unknown>): ConfigWritePreview {
  const existed = existsSync(filePath);
  const beforeRaw = readRawConfigObject(filePath);
  const beforeText = existed ? serializeRawConfig(beforeRaw) : "";
  const afterText = serializeRawConfig(nextRaw);
  return {
    path: filePath,
    existed,
    changed: beforeText !== afterText,
    beforeText,
    afterText,
    diffText: buildUnifiedDiff(beforeText, afterText),
  };
}

function readRawConfigObject(filePath: string): Record<string, unknown> {
  if (!lstatSync(filePath, { throwIfNoEntry: false })) return {};

  try {
    const text = readFileSync(filePath, "utf-8");
    if (text.trim() === "") return {};
    const raw = parseJsonWithComments(text);
    if (!isRecord(raw)) throw new Error("top-level value must be an object");
    return raw;
  } catch (error) {
    throw new Error(`Failed to read MCP config at ${filePath}: ${error instanceof Error ? error.message : String(error)}`, { cause: error });
  }
}

function writeConfigText(writePath: string, text: string): void {
  const originalPath = writePath;
  let mode: number | undefined;
  try {
    writePath = realpathSync(writePath);
    mode = statSync(writePath).mode & 0o777;
  } catch (error) {
    if (lstatSync(originalPath, { throwIfNoEntry: false })?.isSymbolicLink()) {
      throw new Error(`Cannot write MCP config at ${originalPath}: symbolic link target is unavailable`, { cause: error });
    }
  }
  mkdirSync(dirname(writePath), { recursive: true });
  const tmpPath = `${writePath}.${process.pid}.tmp`;
  rmSync(tmpPath, { force: true });
  try {
    writeFileSync(tmpPath, text, mode === undefined ? "utf-8" : { encoding: "utf-8", mode });
    if (mode !== undefined) chmodSync(tmpPath, mode);
    renameSync(tmpPath, writePath);
  } catch (error) {
    try { rmSync(tmpPath, { force: true }); } catch {}
    throw error;
  }
}

function writeRawConfigObject(filePath: string, raw: Record<string, unknown>): void {
  writeConfigText(filePath, `${JSON.stringify(raw, null, 2)}\n`);
}

export function writeSharedConfigText(filePath: string, text: string): void {
  if (!isRecord(parseJsonWithComments(text))) throw new Error("top-level value must be an object");
  writeConfigText(filePath, text);
}

export function writeJevSemanticSearchConfig(
  overridePath: string | undefined,
  cwd: string,
  allowedServers: string[],
  effectiveJev?: unknown,
): { path: string; changed: boolean } {
  const filePath = overridePath ? getPiGlobalConfigPath(overridePath) : getProjectPiConfigPath(cwd);
  const raw = readRawConfigObject(filePath);
  if (raw.settings !== undefined && !isRecord(raw.settings)) {
    throw new Error(`Failed to update Jev settings at ${filePath}: settings must be an object`);
  }
  const settings = raw.settings as Record<string, unknown> | undefined;
  const currentJev = settings?.jev;
  if (currentJev !== undefined && currentJev !== false && !isRecord(currentJev)) {
    throw new Error(`Failed to update Jev settings at ${filePath}: settings.jev must be an object or false`);
  }
  const jev = isRecord(effectiveJev) ? effectiveJev : isRecord(currentJev) ? currentJev : {};
  const nextServers = [...new Set(allowedServers)].sort((a, b) => a.localeCompare(b));
  const nextJev = { ...jev, semanticSearch: true, allowedServers: nextServers };
  validateJevSettings(nextJev);
  if (isRecord(currentJev) && JSON.stringify(currentJev) === JSON.stringify(nextJev)) return { path: filePath, changed: false };
  raw.settings = { ...settings, jev: nextJev };
  writeRawConfigObject(filePath, raw);
  return { path: filePath, changed: true };
}

function getServersObject(raw: Record<string, unknown>, filePath: string): Record<string, ServerEntry> {
  for (const key of ["mcpServers", "mcp-servers"]) {
    if (Object.hasOwn(raw, key) && !isRecord(raw[key])) {
      throw new Error(`Failed to update MCP config at ${filePath}: ${key} must be an object`);
    }
  }
  return (raw.mcpServers ?? raw["mcp-servers"] ?? {}) as Record<string, ServerEntry>;
}

function getConfigImports(raw: Record<string, unknown>, filePath: string): ImportKind[] {
  if (raw.imports === undefined) return [];
  if (!Array.isArray(raw.imports) || raw.imports.some((value) => typeof value !== "string")) {
    throw new Error(`Failed to update MCP config at ${filePath}: imports must be an array of strings`);
  }
  return raw.imports as ImportKind[];
}

function setServersObject(raw: Record<string, unknown>, servers: Record<string, ServerEntry>): void {
  delete raw["mcp-servers"];
  raw.mcpServers = servers;
}

export interface ServerDisabledOverrideResult {
  path: string;
  changed: boolean;
}

/**
 * Persist only the disabled field in the project Pi layer. Enabling writes an
 * explicit false only when a lower-precedence source is itself disabled; this
 * writer never copies a server definition or its credentials into the file.
 */
export function writeProjectServerDisabledOverride(
  overridePath: string | undefined,
  cwd: string,
  serverName: string,
  disabled: boolean,
): ServerDisabledOverrideResult {
  const filePath = getProjectPiConfigPath(cwd);
  const raw = readRawConfigObject(filePath);

  const serverKey = raw.mcpServers !== undefined ? "mcpServers" : raw["mcp-servers"] !== undefined ? "mcp-servers" : "mcpServers";
  const rawServers = raw[serverKey];
  if (rawServers !== undefined && (!rawServers || typeof rawServers !== "object" || Array.isArray(rawServers))) {
    throw new Error(`Failed to update project MCP override at ${filePath}: ${serverKey} must be an object`);
  }
  const servers = (rawServers ?? {}) as Record<string, unknown>;
  const previous = servers[serverName];
  if (previous !== undefined && (!previous || typeof previous !== "object" || Array.isArray(previous))) {
    throw new Error(`Failed to update project MCP override at ${filePath}: server "${serverName}" must be an object`);
  }
  const existing = previous as Record<string, unknown> | undefined;

  let next: Record<string, unknown>;
  if (disabled) {
    next = { ...existing, disabled: true };
  } else {
    next = Object.fromEntries(Object.entries(existing ?? {}).filter(([key]) => key !== "disabled"));
    let lowerConfig: McpConfig = { mcpServers: {} };
    for (const source of getConfigSources(overridePath, cwd)) {
      if (source.readPath === filePath) continue;
      const loaded = readValidatedConfig(source.readPath, `MCP config from ${source.readPath}`);
      if (loaded) lowerConfig = mergeConfigs(lowerConfig, expandImports(loaded, cwd).config);
    }
    if (raw.imports !== undefined) {
      if (!Array.isArray(raw.imports) || raw.imports.some((kind) => typeof kind !== "string" || !Object.hasOwn(IMPORT_PATHS, kind))) {
        throw new Error(`Failed to update project MCP override at ${filePath}: imports contains an unsupported config kind`);
      }
      lowerConfig = mergeConfigs(lowerConfig, expandImports({ mcpServers: {}, imports: raw.imports as ImportKind[] }, cwd).config);
    }
    if (isServerDisabled(lowerConfig.mcpServers[serverName])) next.disabled = false;
  }

  if ((!existing && Object.keys(next).length === 0) || JSON.stringify(existing) === JSON.stringify(next)) {
    return { path: filePath, changed: false };
  }
  if (Object.keys(next).length === 0) delete servers[serverName];
  else servers[serverName] = next;

  raw[serverKey] = servers;
  writeRawConfigObject(filePath, raw);
  return { path: filePath, changed: true };
}

function isRepoPromptServer(name: string, entry: ServerEntry): boolean {
  const normalizedName = name.toLowerCase();
  if (normalizedName.includes("repoprompt") || normalizedName === "rp") {
    return true;
  }

  const command = entry.command?.toLowerCase() ?? "";
  if (command.includes("repoprompt") || command.includes("rp-mcp") || command.endsWith("repoprompt_cli")) {
    return true;
  }

  return (entry.args ?? []).some((arg) => typeof arg === "string" && arg.toLowerCase().includes("repoprompt"));
}

function findProjectRoot(cwd = process.cwd()): string | null {
  let current = resolve(cwd);
  while (true) {
    if (
      existsSync(join(current, ".git"))
      || existsSync(join(current, "package.json"))
      || existsSync(join(current, PROJECT_CONFIG_NAME))
      || existsSync(join(current, ".pi"))
    ) {
      return current;
    }

    const parent = dirname(current);
    if (parent === current) return null;
    current = parent;
  }
}

function buildRepoPromptEntry(executablePath: string): ServerEntry {
  return {
    command: executablePath,
    args: [],
    lifecycle: "lazy",
  };
}

function detectRepoPrompt(summary: Omit<McpDiscoverySummary, "fingerprint" | "repoPrompt">, cwd = process.cwd()): RepoPromptDiscovery {
  for (const source of summary.sources) {
    if (source.kind !== "shared" || source.serverCount === 0) continue;
    const config = readValidatedConfig(source.path, `MCP config from ${source.path}`);
    if (!config) continue;
    for (const [name, entry] of Object.entries(config.mcpServers)) {
      if (isRepoPromptServer(name, entry)) {
        return { configured: true, configuredPath: source.path };
      }
    }
  }

  const executablePath = REPOPROMPT_BINARY_CANDIDATES.find((candidate) => existsSync(candidate));
  if (!executablePath) {
    return { configured: false };
  }

  const projectRoot = findProjectRoot(cwd);
  const targetPath = projectRoot ? join(projectRoot, PROJECT_CONFIG_NAME) : GENERIC_GLOBAL_CONFIG_PATH;
  return {
    configured: false,
    executablePath,
    targetPath,
    serverName: "repoprompt",
    entry: buildRepoPromptEntry(executablePath),
  };
}

export function previewCompatibilityImports(importKinds: ImportKind[], overridePath?: string): ConfigWritePreview {
  const targetPath = getPiGlobalConfigPath(overridePath);
  const raw = readRawConfigObject(targetPath);
  const currentImports = getConfigImports(raw, targetPath);
  const merged = [...new Set([...currentImports, ...importKinds])];
  const nextRaw = { ...raw, imports: merged };
  setServersObject(nextRaw, getServersObject(nextRaw, targetPath));
  return buildConfigWritePreview(targetPath, nextRaw);
}

export function ensureCompatibilityImports(importKinds: ImportKind[], overridePath?: string): { path: string; added: ImportKind[] } {
  const targetPath = getPiGlobalConfigPath(overridePath);
  const raw = readRawConfigObject(targetPath);
  const currentImports = getConfigImports(raw, targetPath);
  const merged = [...new Set([...currentImports, ...importKinds])];
  const added = merged.filter((kind) => !currentImports.includes(kind));
  if (added.length === 0) {
    return { path: targetPath, added: [] };
  }

  raw.imports = merged;
  const servers = getServersObject(raw, targetPath);
  setServersObject(raw, servers);
  writeRawConfigObject(targetPath, raw);
  return { path: targetPath, added };
}

export function buildStarterProjectConfig(): McpConfig {
  return {
    mcpServers: {},
  };
}

function assertScaffoldTargetAbsent(filePath: string): void {
  if (lstatSync(filePath, { throwIfNoEntry: false })) throw new Error(`Cannot scaffold MCP config at ${filePath}: file already exists`);
}

export function previewStarterSharedConfig(target: SharedConfigTarget, cwd = process.cwd()): ConfigWritePreview {
  const targetPath = getSharedConfigPath(target, cwd);
  assertScaffoldTargetAbsent(targetPath);
  const nextRaw = { mcpServers: buildStarterProjectConfig().mcpServers };
  return buildConfigWritePreview(targetPath, nextRaw);
}

export function writeStarterSharedConfig(target: SharedConfigTarget, cwd = process.cwd()): string {
  const targetPath = getSharedConfigPath(target, cwd);
  assertScaffoldTargetAbsent(targetPath);
  const raw = { mcpServers: buildStarterProjectConfig().mcpServers };
  writeRawConfigObject(targetPath, raw);
  return targetPath;
}

export function previewStarterProjectConfig(cwd = process.cwd()): ConfigWritePreview {
  return previewStarterSharedConfig("project", cwd);
}

export function writeStarterProjectConfig(cwd = process.cwd()): string {
  return writeStarterSharedConfig("project", cwd);
}

export function previewSharedServerEntry(filePath: string, serverName: string, entry: ServerEntry): ConfigWritePreview {
  const raw = readRawConfigObject(filePath);
  const nextRaw = { ...raw };
  const servers = getServersObject(nextRaw, filePath);
  servers[serverName] = entry;
  setServersObject(nextRaw, servers);
  return buildConfigWritePreview(filePath, nextRaw);
}

export function writeSharedServerEntry(filePath: string, serverName: string, entry: ServerEntry): string {
  const raw = readRawConfigObject(filePath);
  const servers = getServersObject(raw, filePath);
  servers[serverName] = entry;
  setServersObject(raw, servers);
  writeRawConfigObject(filePath, raw);
  return filePath;
}

export function getServerProvenance(overridePath?: string, cwd = process.cwd()): Map<string, ServerProvenance> {
  const provenance = new Map<string, ServerProvenance>();
  const userPath = getPiGlobalConfigPath(overridePath);

  if (getConfiguredHostConfigDiscovery(overridePath, cwd) === "on") {
    for (const importKind of Object.keys(IMPORT_PATHS) as ImportKind[]) {
      const imported = loadImportedConfig(importKind, cwd, `Failed to inspect imported MCP config from ${importKind}:`);
      if (!imported) continue;
      for (const name of Object.keys(extractServers(imported.value, importKind))) {
        // Keep writes inside adapter-owned storage even though the source is external.
        // Later import kinds win in the same deterministic order as loadDiscoveredHostConfigs.
        provenance.set(name, { path: userPath, kind: "import", importKind });
      }
    }
  }

  for (const source of getConfigSources(overridePath, cwd)) {
    const loaded = readValidatedConfig(source.readPath, `MCP config from ${source.readPath}`);
    if (!loaded) continue;

    if (loaded.imports?.length) {
      for (const importKind of loaded.imports) {
        const imported = loadImportedConfig(importKind, cwd, `Failed to inspect imported MCP config from ${importKind}:`);
        if (!imported) continue;

        const servers = extractServers(imported.value, importKind);
        for (const name of Object.keys(servers)) {
          if (!provenance.has(name)) {
            provenance.set(name, { path: userPath, kind: "import", importKind });
          }
        }
      }
    }

    for (const name of Object.keys(loaded.mcpServers)) {
      provenance.set(name, {
        path: source.writePath,
        kind: source.kind,
        ...(source.importKind !== undefined ? { importKind: source.importKind } : {}),
      });
    }
  }

  return provenance;
}

export function writeDirectToolsConfig(
  changes: Map<string, true | string[] | false>,
  provenance: Map<string, ServerProvenance>,
  fullConfig: McpConfig,
  onFileWritten?: () => void,
): void {
  const byPath = new Map<string, { name: string; value: true | string[] | false; prov: ServerProvenance }[]>();

  for (const [serverName, value] of changes) {
    const prov = provenance.get(serverName);
    if (!prov) continue;

    const targetPath = prov.path;

    if (!byPath.has(targetPath)) byPath.set(targetPath, []);
    byPath.get(targetPath)!.push({ name: serverName, value, prov });
  }

  // Validate every target before writing any, then re-read each one: two paths can alias one file.
  for (const filePath of byPath.keys()) getServersObject(readRawConfigObject(filePath), filePath);

  for (const [filePath, entries] of byPath) {
    const raw = readRawConfigObject(filePath);
    const servers = getServersObject(raw, filePath);
    for (const { name, value, prov } of entries) {
      if (prov.kind === "import") {
        const fullDef = fullConfig.mcpServers[name];
        if (fullDef) {
          servers[name] = { ...fullDef, directTools: value };
        }
      } else if (servers[name]) {
        servers[name] = { ...servers[name], directTools: value };
      }
    }

    setServersObject(raw, servers);
    writeRawConfigObject(filePath, raw);
    onFileWritten?.();
  }
}

export function resolveConfiguredOAuthDir(raw: unknown, cwd = process.cwd()): string | undefined {
  if (raw === undefined || raw === null) return undefined;
  if (typeof raw !== "string") {
    throw new Error("settings.oauthDir must be a string");
  }

  const trimmed = raw.trim();
  if (!trimmed) return undefined;
  return resolve(cwd, trimmed);
}
